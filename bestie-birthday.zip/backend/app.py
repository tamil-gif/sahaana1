import os
import json
import shutil
from typing import Optional, List, Dict, Any
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

app = FastAPI(title="Bestie Birthday API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
UPLOADS_DIR = os.path.join(DATA_DIR, "uploads")
SETTINGS_FILE = os.path.join(DATA_DIR, "settings.json")
PHOTOS_FILE = os.path.join(DATA_DIR, "photos.json")

os.makedirs(UPLOADS_DIR, exist_ok=True)

DEFAULT_SETTINGS = {
    "key": "main",
    "name": "Sahaana",
    "birthday_date": "2026-11-03T00:00:00+05:30",
    "favourite_caption": "[Write here why this photo is so special to you — this text is yours to fill in]",
    "meet_heading": "The Day Our Paths Crossed...",
    "meet_date": "",
    "meet_message": "[Write your personal message about the day you two first met — this text is yours to fill in]",
    "timeline": []
}

def read_settings():
    if os.path.exists(SETTINGS_FILE):
        try:
            with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return DEFAULT_SETTINGS

def write_settings(data):
    with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

def read_photos():
    if os.path.exists(PHOTOS_FILE):
        try:
            with open(PHOTOS_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return []

def write_photos(data):
    with open(PHOTOS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

@app.get("/api/settings")
def get_settings():
    return read_settings()

@app.put("/api/settings")
def update_settings(body: Dict[str, Any]):
    current = read_settings()
    current.update(body)
    current["key"] = "main"
    write_settings(current)
    return current

@app.get("/api/photos")
def get_photos():
    return read_photos()

@app.post("/api/photos")
async def create_photo(
    file: UploadFile = File(...),
    caption: str = Form(""),
    date: str = Form("")
):
    import time
    ext = os.path.splitext(file.filename)[1] or ".jpg"
    filename = f"{int(time.time()*1000)}_{os.urandom(4).hex()}{ext}"
    dest = os.path.join(UPLOADS_DIR, filename)
    with open(dest, "wb") as f:
        shutil.copyfileobj(file.file, f)

    photos = read_photos()
    is_first = len(photos) == 0
    photo = {
        "id": f"p_{int(time.time()*1000)}_{os.urandom(3).hex()}",
        "url": f"/api/photos/files/{filename}",
        "caption": caption,
        "date": date,
        "is_favourite": is_first
    }
    photos.append(photo)
    write_photos(photos)
    return photo

class PatchPhotoBody(BaseModel):
    is_favourite: Optional[bool] = None
    caption: Optional[str] = None
    date: Optional[str] = None

@app.patch("/api/photos/{photo_id}")
def patch_photo(photo_id: str, body: PatchPhotoBody):
    photos = read_photos()
    found = None
    for p in photos:
        if p["id"] == photo_id:
            found = p
            break
    if not found:
        raise HTTPException(status_code=404, detail="Photo not found")

    if body.is_favourite is not None:
        for p in photos:
            p["is_favourite"] = (p["id"] == photo_id) if body.is_favourite else False

    if body.caption is not None:
        found["caption"] = body.caption
    if body.date is not None:
        found["date"] = body.date

    write_photos(photos)
    return found

@app.delete("/api/photos/{photo_id}")
def delete_photo(photo_id: str):
    photos = read_photos()
    target = None
    for p in photos:
        if p["id"] == photo_id:
            target = p
            break
    if target:
        filename = os.path.basename(target["url"])
        file_path = os.path.join(UPLOADS_DIR, filename)
        if os.path.exists(file_path):
            try:
                os.remove(file_path)
            except Exception:
                pass
    photos = [p for p in photos if p["id"] != photo_id]
    write_photos(photos)
    return {"success": True, "id": photo_id}

app.mount("/api/photos/files", StaticFiles(directory=UPLOADS_DIR), name="photos")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=5001)
