import express from "express";
import cors from "cors";
import multer from "multer";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5001;

const DATA_DIR = path.join(__dirname, "data");
const UPLOADS_DIR = path.join(DATA_DIR, "uploads");
const SETTINGS_FILE = path.join(DATA_DIR, "settings.json");
const PHOTOS_FILE = path.join(DATA_DIR, "photos.json");

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });

const DEFAULT_SETTINGS = {
  key: "main",
  name: "Sahaana",
  birthday_date: "2026-11-03T00:00:00+05:30",
  favourite_caption:
    "[Write here why this photo is so special to you — this text is yours to fill in]",
  meet_heading: "The Day Our Paths Crossed...",
  meet_date: "",
  meet_message:
    "[Write your personal message about the day you two first met — this text is yours to fill in]",
  timeline: [],
};

function readSettings() {
  try {
    if (fs.existsSync(SETTINGS_FILE)) {
      return JSON.parse(fs.readFileSync(SETTINGS_FILE, "utf-8"));
    }
  } catch (e) {
    console.error("Error reading settings:", e);
  }
  return DEFAULT_SETTINGS;
}

function writeSettings(data) {
  fs.writeFileSync(SETTINGS_FILE, JSON.stringify(data, null, 2), "utf-8");
}

function readPhotos() {
  try {
    if (fs.existsSync(PHOTOS_FILE)) {
      return JSON.parse(fs.readFileSync(PHOTOS_FILE, "utf-8"));
    }
  } catch (e) {
    console.error("Error reading photos:", e);
  }
  return [];
}

function writePhotos(data) {
  fs.writeFileSync(PHOTOS_FILE, JSON.stringify(data, null, 2), "utf-8");
}

app.use(cors());
app.use(express.json());

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOADS_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname) || ".jpg";
    const unique = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}${ext}`;
    cb(null, unique);
  },
});
const upload = multer({ storage });

// API Endpoints
app.get("/api/settings", (req, res) => {
  res.json(readSettings());
});

app.put("/api/settings", (req, res) => {
  const current = readSettings();
  const updated = { ...current, ...req.body, key: "main" };
  writeSettings(updated);
  res.json(updated);
});

app.get("/api/photos", (req, res) => {
  res.json(readPhotos());
});

app.post("/api/photos", upload.single("file"), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: "No file uploaded" });
  }

  const photos = readPhotos();
  const id = `p_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
  const isFirst = photos.length === 0;

  const newPhoto = {
    id,
    url: `/api/photos/files/${req.file.filename}`,
    caption: req.body.caption || "",
    date: req.body.date || "",
    is_favourite: isFirst,
  };

  photos.push(newPhoto);
  writePhotos(photos);
  res.status(201).json(newPhoto);
});

app.patch("/api/photos/:id", (req, res) => {
  const { id } = req.params;
  const { is_favourite, caption, date } = req.body;
  const photos = readPhotos();
  const photo = photos.find((p) => p.id === id);

  if (!photo) {
    return res.status(404).json({ error: "Photo not found" });
  }

  if (is_favourite !== undefined) {
    photos.forEach((p) => {
      p.is_favourite = p.id === id ? Boolean(is_favourite) : false;
    });
  }

  if (caption !== undefined) photo.caption = caption;
  if (date !== undefined) photo.date = date;

  writePhotos(photos);
  res.json(photo);
});

app.delete("/api/photos/:id", (req, res) => {
  const { id } = req.params;
  let photos = readPhotos();
  const photo = photos.find((p) => p.id === id);

  if (photo) {
    const filename = path.basename(photo.url);
    const filePath = path.join(UPLOADS_DIR, filename);
    if (fs.existsSync(filePath)) {
      try {
        fs.unlinkSync(filePath);
      } catch (err) {}
    }
  }

  photos = photos.filter((p) => p.id !== id);
  writePhotos(photos);
  res.json({ success: true, id });
});

// Serve uploaded photo files
app.use("/api/photos/files", express.static(UPLOADS_DIR));

// Serve production build if exists
const DIST_DIR = path.join(__dirname, "..", "dist");
if (fs.existsSync(DIST_DIR)) {
  app.use(express.static(DIST_DIR));
  app.get("*", (req, res) => {
    res.sendFile(path.join(DIST_DIR, "index.html"));
  });
}

app.listen(PORT, () => {
  console.log(`Backend server running at http://localhost:${PORT}`);
});
