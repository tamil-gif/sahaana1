import { useEffect, useRef, useState } from "react";
import { Play, Pause, Volume2, VolumeX, Loader2 } from "lucide-react";

const VIDEO_ID = "My_S68DAAPg";
const START_TIME = 95; // 1 minute 35 seconds (1:35)

export const music = {
  play: () => {},
  pause: () => {},
  toggle: () => {},
};

export default function MusicPlayer({ hidden = false }) {
  const hostRef = useRef(null);
  const playerRef = useRef(null);
  const [ready, setReady] = useState(false);
  const [started, setStarted] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(false);
  const startedRef = useRef(false);

  useEffect(() => {
    let destroyed = false;
    const ensure = () => {
      if (destroyed) return;
      if (window.YT && window.YT.Player && hostRef.current) {
        if (playerRef.current) return;
        hostRef.current.innerHTML = "";
        const host = document.createElement("div");
        hostRef.current.appendChild(host);
        playerRef.current = new window.YT.Player(host, {
          videoId: VIDEO_ID,
          playerVars: {
            autoplay: 0,
            controls: 0,
            disablekb: 1,
            loop: 1,
            playlist: VIDEO_ID,
            playsinline: 1,
            modestbranding: 1,
            start: START_TIME,
          },
          events: {
            onReady: (e) => {
              e.target.setVolume(75);
              try {
                e.target.seekTo(START_TIME, true);
              } catch (err) {}
              setReady(true);
              if (startedRef.current) {
                try {
                  e.target.seekTo(START_TIME, true);
                  e.target.playVideo();
                } catch (err) {}
              }
            },
            onStateChange: (e) => {
              setPlaying(e.data === window.YT.PlayerState.PLAYING);
              if (e.data === window.YT.PlayerState.ENDED) {
                try {
                  e.target.seekTo(START_TIME, true);
                  e.target.playVideo();
                } catch (err) {}
              }
            },
          },
        });
      } else {
        setTimeout(ensure, 250);
      }
    };
    if (!document.getElementById("yt-iframe-api")) {
      const s = document.createElement("script");
      s.id = "yt-iframe-api";
      s.src = "https://www.youtube.com/iframe_api";
      document.body.appendChild(s);
    }
    window.onYouTubeIframeAPIReady = ensure;
    ensure();
    return () => {
      destroyed = true;
    };
  }, []);

  useEffect(() => {
    music.play = () => {
      startedRef.current = true;
      setStarted(true);
      try {
        const curTime = playerRef.current?.getCurrentTime?.();
        if (!curTime || curTime < START_TIME) {
          playerRef.current?.seekTo(START_TIME, true);
        }
        playerRef.current?.playVideo();
      } catch (e) {}
    };
    music.pause = () => {
      startedRef.current = false;
      try {
        playerRef.current?.pauseVideo();
      } catch (e) {}
    };
    music.toggle = () => {
      startedRef.current = true;
      setStarted(true);
      try {
        const st = playerRef.current?.getPlayerState();
        if (st === 1) playerRef.current.pauseVideo();
        else playerRef.current.playVideo();
      } catch (e) {}
    };
  }, [ready]);

  const toggleMute = () => {
    try {
      if (muted) playerRef.current?.unMute();
      else playerRef.current?.mute();
      setMuted(!muted);
    } catch (e) {}
  };

  return (
    <>
      <div ref={hostRef} className="yt-host" aria-hidden="true" />
      {!hidden && started && (
        <div className="music-pill" data-testid="music-player">
          <button
            className="music-btn"
            data-testid="music-toggle-button"
            onClick={() => music.toggle()}
            aria-label={playing ? "Pause music" : "Play music"}
          >
            {ready ? (
              playing ? (
                <Pause size={15} />
              ) : (
                <Play size={15} />
              )
            ) : (
              <Loader2 size={15} className="spin-slow" />
            )}
          </button>
          <span className="music-label">Aval — Manithan</span>
          <button
            className="music-btn"
            data-testid="music-mute-button"
            onClick={toggleMute}
            aria-label={muted ? "Unmute music" : "Mute music"}
          >
            {muted ? <VolumeX size={14} /> : <Volume2 size={14} />}
          </button>
        </div>
      )}
    </>
  );
}
